
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define nw (line *)malloc(sizeof(struct line))
typedef struct line
{
	char l[50];
	struct line *prev,*next;
}line;
struct line *head,*temp,*temp1,*temp2;
void help()
{
	printf("\ta    : Apend");
	printf("\n\tp m n: Print line's m to n");
	printf("\n\ti n  : Insert at n position");
	printf("\n\te    : Exit\n");
}
line *apend(FILE *fp)
{
	int n,i;
	char *ch,ln[50];
	if(head==NULL)
	{
	do
	{
		ch=fgets(ln,50,fp);
		if(ch==NULL)
			break;
		if(head==NULL)
		{
			temp=nw;
			head=temp1=temp;
			temp->next=temp->prev=NULL;
			strcpy(temp->l,ln);
		}
		else
		{
			temp->next=nw;
			temp=temp->next;
			temp->prev=temp1;
			temp->next=NULL;
			temp1=temp;
			strcpy(temp->l,ln);
		}
	}while(1);
	fclose(fp);
	}
	else
	{
		temp=head;
		while(temp->next!=NULL)
			temp=temp->next;
		temp1=temp;
	}
	printf("Enter the total line's you want to apend:");
	scanf("%d",&n);
	printf("Enter the %d line's\n",n);
	for(i=0;i<=n;i++)
	{
		temp->next=nw;
		temp=temp->next;
		temp->next=NULL;
		temp->prev=temp1;
		temp1=temp;
		gets(temp->l);
		strcat(temp->l,"\n");
	}
	return head;
}
void print1(line *head,int m,int n)
{
	int i;
	temp=head;
	for(i=1;i<m;i++)
		temp=temp->next;
	for(;i<=n;i++)
	{
		printf("%s",temp->l);
		temp=temp->next;
	}
}
line *insert(line *head,int n)
{
	int i;
	printf("\nEnter the Line:");
	if(n==1)
	{
		temp=nw;
		temp->next=head;
		temp->prev=NULL;
		head->prev=temp;
		head=temp;
		gets(temp->l);
		strcat(temp->l,"\n");
	}
	else
	{
		temp=head;
		for(i=2;i<n;i++)
			temp=temp->next;
		temp1=nw;
		gets(temp1->l);
		strcat(temp->l,"\n");
		temp->next->prev=temp1;
		temp1->next=temp->next;
		temp->next=temp1;
		temp1->prev=temp;
	}
	return head;
}
void main(int argc,char *argv[])
{
	FILE *fp;
	char ch[4],c[1];
	int no,n1,n2;
	if(argc==1)
		fp=fopen("abcd.txt","r+");
	if(argc==2)
		fp=fopen(argv[1],"r+");
	if(fp!=NULL)
	{
	printf("--->Press h for help\n");
	do
	{
		printf("$");
		ch[0]='\0';
		gets(ch);
		if(ch[0]=='\0')
			continue;
		no=sscanf(ch,"%s %d %d",c,&n1,&n2);
		switch(c[0])
		{
			case 'h':help();
				break;
			case 'a':head=apend(fp);
				break;
			case 'p':if(no==3)
					print1(head,n1,n2);
				else
					printf("\nError:Invalid Argument Pass");
				break;
			case 'i':if(no==2)
					head=insert(head,n1);
				else
					printf("\nError:Invalid Argument Pass");
			case 'e':break;
			default:printf("\nError:Command Not Found");
				break;
		}
	}while(c[0]!='e');
	}
	else
		printf("Unable to open File");
}				

