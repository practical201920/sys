

#include<stdio.h>
int n=5,m=4;//n for no of process and m is for no of resources
int alloc[10][10]={{0,0,1,2},{1,0,0,0},{1,3,5,4},{0,6,3,2},{0,0,1,4}},max[10][10]={{0,0,1,2},{1,7,5,0},{2,3,5,6},{0,6,5,2},{0,6,5,6}},need[10][10];
int available[10]={1,5,2,0},work[10],finish[10],seq[10],req[10];
int pno;
void calc_need()
{
	int i,j;
	for(i=0;i<n;i++)
		for(j=0;j<m;j++)
		need[i][j]=max[i][j]-alloc[i][j];
}
void print()
{
	int i,j;
	printf("\n\tAllocation\t\tMax\t\tNeed\n\t");
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		printf("%3c",65+j);
		printf("\t");
	}
	for(i=0;i<n;i++)
	{
		printf("\np%d\t",i);
		for(j=0;j<m;j++)
			printf("%3d",alloc[i][j]);
			printf("\t");
		for(j=0;j<m;j++)
			printf("%3d",max[i][j]);
                        printf("\t");
                for(j=0;j<m;j++)
        		printf("%3d",need[i][j]);
                        printf("\t");
	}
	printf("\nAvailable\n");
	 for(j=0;j<m;j++){
                        printf("%3c",65+j);
                        printf("\t");
			}
			printf("\n");
	 for(j=0;j<m;j++)
                      {  printf("%3d",available[j]);
                        printf("\t");
			}
}
int find()
{
	int i,j;
        for(i=0;i<n;i++)
        {
		if(!finish[i])
		{
	       	        for(j=0;j<m;j++)
        	        if(need[i][j]>work[j])
                	break;
			if(j==m) return i;
		}
	}
	return -1;
}
void bankers()
{
	int i,j,k=0;
	 for(i=0;i<n;i++)
              finish[i]=0;
         for(j=0;j<m;j++)
               work[j]=available[j];
	 while((i=find())!=-1)
	{
		printf("\nNeed%d(",i);
		for(j=0;j<m;j++)
			printf("%d,",need[i][j]);
		printf("\b)<=work(");
		for(j=0;j<m;j++)
			printf("%d,",work[j]);
			printf("\b)");
			finish[i]=1;
		for(j=0;j<m;j++)
			work[j] +=alloc[i][j];
		printf("\nwork(");
		for(j=0;j<m;j++)
			printf("%d,",work[j]);
			printf("\b)\nFinish(");
		for(j=0;j<n;j++)
			printf("%d,",finish[j]);
			printf("\b)");
			seq[k++]=i;
	}
	if(k==n)
	{
		printf("\n System is in safe state:\nsafe sequence:");
		for(j=0;j<n;j++)
		printf("p%d-",seq[j]);
	}
	else
	{
		printf("\n System is in unsafe state");
	}
}
void main()
{
	int i,j;
	calc_need();
	print();
	bankers();
	printf("\n Enter process no:");
	scanf("%d",&pno);
	printf("Enter request of process p%d\n",pno);
	for(j=0;j<m;j++)
	{
		printf("%c:",65+j);
		scanf("%d",&req[j]);
	}
	for(j=0;j<m;j++)
		if(req[j]>need[pno][j]) break;
		if(j==m)
		{
			for(j=0;j<m;j++)
			if(req[j]>available[j]) break;
			if(j==m)
			{
				for(j=0;j<m;j++)
				{
					available[j]-=req[j];
					alloc[pno][j]+=req[j];
					need[pno][j]-=req[j];
				}
				print();
				bankers();
		   printf("\n Request of process p%d can be generated\n",pno);
			}
			else
			{
				printf("\n Process p%d has to wait\n",pno);
			}
		}
		else
		{
		   printf("\n Request of process p%d cannot be generated\n",pno);
		}
}

