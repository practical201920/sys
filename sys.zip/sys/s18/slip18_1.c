
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define nw (line *)malloc(sizeof(struct line))
typedef struct line
{
	char l[50];
	struct line *prev,*next;
}line;
struct line *head,*temp,*temp1,*temp2,*temp3;
void help()
{
	printf("\ta          : Apend");
	printf("\n\tp          : Print");
	printf("\n\tm n1 n2    : Move n1 line after the n2 line");
	printf("\n\ts		: Save");
	printf("\n\te          : Exit\n");
}
void save(char nme[10])
{
	FILE *fp=fopen(nme,"w");
	if(fp==NULL)
		printf("Unable to save file");
	else
	{
		temp=head;
		while(temp!=NULL)
		{
			fputs(temp->l,fp);
			fputs("\n",fp);
			temp=temp->next;
		}
		fclose(fp);
	}
}
line *apend(FILE *fp)
{
	int i,n;
	char ln[50],*ch;
	if(head==NULL)
	{
	do
	{
		ch=fgets(ln,50,fp);
		if(ch==NULL)
			break;
		if(head==NULL)
		{
			temp=nw;
			temp->next=temp->prev=NULL;
			head=temp1=temp;
			strcpy(temp->l,ln);
		}
		else
		{
			temp->next=nw;
			temp=temp->next;
			temp->prev=temp1;
			temp->next=NULL;
			strcpy(temp->l,ln);
			temp1=temp;
		}
	}while(1);
	fclose(fp);
	}
	else
	{
		temp=head;
		while(temp->next!=NULL)
			temp=temp->next;
		temp1=temp;
	}
	printf("Enter the total line's you want to apend:");
	scanf("%d",&n);
	printf("Enter the %d line's\n",n);
	for(i=0;i<=n;i++)
	{
		temp->next=nw;
		temp=temp->next;
		temp->next=NULL;
		temp->prev=temp1;
		gets(temp->l);
		strcat(temp->l,"\n");
		temp1=temp;
	}
	return head;
}
void print(line *head)
{
	temp=head;
	while(temp!=NULL)
	{
		printf("%s",temp->l);
		temp=temp->next;
	}
}
line *move(line *head,int n1,int n2)
{
	int i;
	temp=head;
	for(i=1;i<n1&&temp!=NULL;i++)
		temp=temp->next;
	if(i==1)
	{
		temp2=head;
		temp=temp->next;
		temp->prev=NULL;
		head=temp;
		for(i=2;i<n2;i++)
			temp=temp->next;
		if(temp->next==NULL)
		{
			temp->next=temp2;
			temp2->prev=temp;
			temp2->next=NULL;
		}
		else
		{
			temp->next->prev=temp2;
			temp2->next=temp->next;
			temp->next=temp2;
			temp2->prev=temp;
		}
	}
	else
	{
		if(temp->next==NULL)
		{
			temp2=temp;
			temp->prev->next=NULL;
			temp=head;
			for(i=1;i<n2&&temp!=NULL;i++)
				temp=temp->next;
			if(n2==0)
			{
				temp2->prev=NULL;
				temp2->next=temp;
				temp->prev=temp2;
				head=temp2;
			}	
			else if(temp->next==NULL)
			{
				temp->next=temp2;
				temp2->prev=temp;
				temp2->next=NULL;
			}
			else
			{
				temp->next->prev=temp2;
				temp2->next=temp->next;
				temp->next=temp2;
				temp2->prev=temp;
			}
		}
		else
		{
			if(n1<n2)
			{
				temp2=temp;
				temp2->prev->next=temp2->next;
				temp2->next->prev=temp2->prev;
				temp=head;
				for(i=1;i<n2-1;i++)
					temp=temp->next;
				temp->next->prev=temp2;
				temp2->next=temp->next;
				temp->next=temp2;
				temp2->prev=temp;
			}
			else if(n1>n2)
			{
				temp2=temp;
				temp2->prev->next=temp2->next;
				temp2->next->prev=temp2->prev;
				temp=head;
				for(i=1;i<n2;i++)
					temp=temp->next;
				if(n2==0)
				{
					temp2->next=temp;
					temp2->prev=NULL;
					temp->prev=temp2;
					head=temp2;
				}
				else
				{
					temp->next->prev=temp2;
					temp2->next=temp->next;
					temp->next=temp2;
					temp2->prev=temp;
				}
			}
		}
	}
	return head;
}
void main(int argc,char *argv[])
{
	FILE *fp;
	char ch[5],c[1],nme[20];
	int no,n1,n2,n3;
	if(argc==1)
	{
		fp=fopen("abcde.txt","r+");
		strcpy(nme,"abcde.txt");
	}
	if(argc==2)
	{
		fp=fopen(argv[1],"r+");
		strcpy(nme,argv[1]);
	}
	if(fp!=NULL)
	{
	printf("--->Press h for help\n");
	do
	{
		printf("$");
		ch[0]='\0';
		gets(ch);
		if(ch[0]=='\0')
			continue;
		no=sscanf(ch,"%s %d %d %d",c,&n1,&n2,&n3);
		switch(c[0])
		{
			case 'h':help();
				break;
			case 'p':print(head);
				break;
			case 'a':head=apend(fp);
				break;
			case 'm':if(no==3)
					head=move(head,n1,n2);
				else
					printf("Error:Invalid Argument Pass\n");
				break;
			case 'e':break;
			case 's':save(nme);
				break;
			default:printf("Error:Command Not Found\n");
				break;
		}
		
	}while(c[0]!='e');
	}
	else
		printf("Unable to open file");
}
