
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define nw (line *)malloc(sizeof(struct line))
typedef struct line
{
	char l[50];
	struct line *prev,*next;
}*line;
struct line *head,*temp,*temp1,*temp2;
void help()
{
	printf("\ta     : Apend");
	printf("\n\td m n : Delete range of line");
	printf("\n\ts     : Save");
	printf("\n\te     :Exit\n");
}
line *apend(FILE *fp)
{
	int n,i;
	struct line *temp,*temp1;
	char *ch=" ",ln[50];
	if(head==NULL)
	{
	do
	{
		ch=fgets(ln,50,fp);
		if(ch==NULL)
			break;
		if(head==NULL)
		{
			temp=nw;
			head=temp;
			temp1=temp;
			temp->next=temp->prev=NULL;
			strcpy(temp->l,ln);
		}
		else
		{
			temp->next=nw;
			temp=temp->next;
			temp->next=NULL;
			temp->prev=temp1;
			strcpy(temp->l,ln);
			temp1=temp;
		}
	}while(1);
	fclose(fp);
	}
	if(head!=NULL)
	{
		temp=head;
		while(temp->next!=NULL)
			temp=temp->next;
	}	
	printf("Enter total line's you want to apend:");
	scanf("%d",&n);
	printf("Enter %d line's\n",n);
	for(i=0;i<=n;i++)
	{
		temp->next=nw;
		temp=temp->next;
		temp->next=NULL;
		temp->prev=temp1;
		gets(temp->l);
		strcat(temp->l,"\n");
		temp1=temp;
	}
	return head;
}
line *delete(int n)
{
	struct line *temp,*temp1;
	int i;
	temp=temp1=head;
	if(n==1)
	{
		head=head->next;
		head->prev=NULL;
		free(temp);
	}
	else
	{
		for(i=2;i<n&&temp->next!=NULL;i++)
		{
			temp=temp->next;
		}
		if(temp->next->next==NULL)
		{
			temp1=temp->next;
			temp->next=NULL;
			free(temp1);
		}
		else
		{
			temp1=temp->next;
			temp->next=temp1->next;
			temp1->next->prev=temp;
			free(temp1);
		}
	}
	return head;
}

		
line *delete1(int n1,int n2)
{
	int i;
	if(n1==n2)
		return(delete(n1));
	temp=head;
	temp1=head->next;
	if(n1==1)
	{
		for(i=1;i<=n2;i++)
		{
			temp1->prev=NULL;
			free(temp);
			temp=temp1;
			temp1=temp1->next;
		}
		head=temp;
	}
	else
	{
		for(i=1;i<n1;i++)
			temp=temp->next;
		temp2=temp->prev;
		temp1=temp->next;
		for(;i<=n2;i++)
		{
			temp1->prev=NULL;
			free(temp);
			temp=temp1;
			temp1=temp1->next;
		}
		temp2->next=temp;
		temp->prev=temp2;
	}
	return head;
}
void save(char nme[10])
{
	FILE *fp=fopen(nme,"w");
	if(fp==NULL)
		printf("Unable to save file");
	else
	{
		temp=head;
		while(temp!=NULL)
		{
			fputs(temp->l,fp);
			fputs("\n",fp);
			temp=temp->next;
		}
		fclose(fp);
	}
}
void print(line *head)
{
        struct line *temp;
        temp=head;
        while(temp!=NULL)
        {
                printf("%s",temp->l);
                temp=temp->next;
        }
}
int main(int argc,char *argv[])
{
	FILE *fp;
	char ch[5],c[1],nme[10];
	int no,n1,n2;
	if(argc==1)
	{
		fp=fopen("abc.txt","r+");
		strcpy(nme,"abc.txt");
	}
	else if(argc==2)
	{
		fp=fopen(argv[1],"r+");
		strcpy(nme,argv[1]);
	}	
	if(fp!=NULL)
	{
			
	printf("-->Press h for Help\n");
	do
	{
		printf("$");
		ch[0]='\0';
		gets(ch);
		if(ch[0]=='\0')
			continue;
		no=sscanf(ch,"%s %d %d",c,&n1,&n2);
		switch(c[0])
		{
			case 'h':help();
				break;
			case 'p':print(head);
				break;
			case 'a':head=apend(fp);
				break;
			case 'd':if(no==3)
				{
					head=delete1(n1,n2);
				}
				else
				{
					printf("\nError:Invalid Argument Pass");
				}
				break;
			case 's':save(nme);
				break;
			case 'e':break;
			default :printf("\nError:Command Not Found");
				break;
		}
	}while(c[0]!='e');
	
	}
	else
		printf("Unable to open File");
}

