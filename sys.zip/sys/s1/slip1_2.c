
#include<stdio.h>
struct frames
{
	int pno,freq;
}frames[20];
int n;

int page_found(int pno)
{
	int fno;
	for(fno=0;fno<n;fno++)
	{
		if(frames[fno].pno==pno)
			return fno;
	}
	return -1;
}

int get_lfu_frame()
{
	int fno,selfno=0;
	for(fno=1;fno<n;fno++)
	{
		if(frames[fno].freq<frames[selfno].freq)
		selfno=fno;
	}
	return selfno;
}

int get_free_frame()
{
	int fno;
	for(fno=0;fno<n;fno++)
	{
		if(frames[fno].pno==-1)
			return fno;
	}
	return -1;
}

int main()
{
	int p_request[]={3,4,5,4,3,4,7,2,4,5,6,7,2,4,6};
	int size=15;
	int p_fault=0,i,j,fno;
	printf("Enter how many Frames :");
	scanf("%d",&n);
	
	for(i=0;i<n;i++)
	{
		frames[i].pno=-1;
		frames[i].freq=0;
	}

	printf("\nPageNo\tPage Frames\t\tPage Fault");
	printf("\n----------------------------------------\n");
	for(i=0;i<size;i++)
	{
		j=page_found(p_request[i]);
		if(j==-1)
		{
			j=get_free_frame();
			if(j==-1)
				j=get_lfu_frame();
			p_fault++;
			frames[j].pno=p_request[i];
			frames[j].freq=1;
			printf("\n %d\t",p_request[i]);
			for(fno=0;fno<n;fno++)
			{
				printf(" %d:%d ",frames[fno].pno,frames[fno].freq);
			}
			printf(" : YES");
		}
		else
		{
			printf("\n %d \t",p_request[i]);
			frames[j].freq++;
			for(fno=0;fno<n;fno++)
			{
				printf(" %d:%d ",frames[fno].pno,frames[fno].freq);
			}
			printf(" : NO");
		}
		
	}
	printf("\n------------------------------------------------");
	printf("\nNumber of Page Fault : %d",p_fault);
	return 0;
}

