#include<stdio.h>
int main(int argc,char *argv[])
{
	FILE *fp;
	long int instr,op1,op2,i,no,REG[4],Cond[6],Mem[1000];
	int pc=0;
	if(argc==1)
		fp=fopen("Opcode1.txt","r");
	else if(argc==2)
		fp=fopen(argv[1],"r");
	if(fp)
	{
		i=-1;
		while(!feof(fp))
		{
			fscanf(fp,"%ld",&Mem[++i]);
			printf(" %ld\n",Mem[i]);
		}
		fclose(fp);
		do
		{
			A : instr=Mem[pc]/10000;
				op1=(Mem[pc]%10000)/1000;
				op2=Mem[pc]%1000;
				switch(instr)
				{
					case 4:REG[op1-1]=Mem[op2];
						break;
					case 5:Mem[op2]=REG[op1-1];
						break;
					case 9:printf("Enter the value for memory address %ld :",op2);
						scanf("%ld",&Mem[op2]);
						break;
					case 10:printf("The result store in memory address %ld : %ld\n",op2,Mem[op2]);
						break;
					case 6:Cond[5]=1;
						Cond[0]=Cond[1]=Cond[2]=Cond[3]=Cond[4]=0;
						if(REG[op1-1]<Mem[op2])
							Cond[0]=1;
						if(REG[op1-1]<=Mem[op2])
							Cond[1]=1;
						if(REG[op1-1]==Mem[op2])
							Cond[2]=1;
						if(REG[op1-1]>Mem[op2])
							Cond[3]=1;
						if(REG[op1-1]>=Mem[op2])
							Cond[4]=1;
						break;
					case 7:if(Cond[op1-1]==1)
						{
							pc=op2;
							goto A;			
						}
						break;
					case 3:REG[op1-1]*=Mem[op2];
						break;
					case 8:REG[op1-1]/=Mem[op2];
						break;
					case 1:REG[op1-1]+=Mem[op2];
						break;
					case 2:REG[op1-1]-=Mem[op2];
						break;
					case 0:break;
					default:printf("\nERROR:Invalid Instruction");
						break;
				}
				pc++;
		}while(instr!=0);
	}
	else
		printf("Unable to open file");
}

