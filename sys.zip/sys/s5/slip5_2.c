
#include<stdio.h>
#include<string.h>
#include<stdlib.h>

typedef struct file_allocation_table
{
	char name[20];
	int start,len,flag;
	struct file_allocation_table *link;
}DIR;

typedef struct free_blocks_list
{
	int start,len;
	struct free_blocks_list *link;
}NODE;

int d;
DIR *first,*last;
NODE *first1,*last1;

void disp_free_list()
{
	NODE *p;
	printf("\nFree blocks list");
	printf("\nStart\tLength");
	p = first1;
	while(p!=NULL)
	{
		printf("\n%d\t%d",p->start,p->len);
		p=p->link;
	}
}

void disp_dir()
{
	DIR *p;
	printf("\nDir List");
	printf("\nName\tStart\tLength");
	p=first;
	while(p!=NULL)
	{
		if(p->flag==0)
			printf("\n%s\t%d\t%d",p->name,p->start,p->len);
		p=p->link;
	}
}

void main ()
{
	int ch,tno;
	char tfn[20];
	NODE *p;
	DIR *q;
       		
	system("clear");
	printf("Enter no.of disk blocks:");
	scanf("%d",&d);

	first1 = last1 = (NODE*)malloc(sizeof(NODE));
	first1->start = 0;
	first1->len = d;
	first1->link = NULL; 
	
	while(1)	
	{
		printf("\n1.Insertion\n2.Deletion\n3.Display\n4.Exit\nEnter your choice (1-4):");
		scanf("%d",&ch);
		switch(ch)
		{
    		case 1:
			printf("Enter file name:");
			scanf("%s",tfn);
			printf("Enter file size in no.of blocks:");
			scanf("%d",&tno);
			p = first1;
			while(p!=NULL)
			{
				if(p->len >= tno) break;
				p=p->link;
			}
			if(p==NULL)
			{
				printf("Failed to create file %s\n",tfn);
			}
			else
			{
				q = (DIR*)malloc(sizeof(DIR));
				strcpy(q->name,tfn);
				q->len = tno;
				q->start = p->start;
				q->flag = 0;
				q->link = NULL;

				if(first==NULL) first=q;
				else last->link = q;
				last = q;
			
				p->start += tno;
				p->len -= tno;
				printf("File %s created successfully.\n",tfn);
			}
			break;
		case 2:
			printf("Enter file name you want to delete:");
			scanf("%s",tfn);
			q = first;
			while(q!=NULL)
			{
				if(strcmp(q->name,tfn)==0 && q->flag==0) break;
				q=q->link;
			}
			if(q==NULL)
			{
				printf("File %s not found.\n",tfn);
			}
			else
			{
				q->flag = 1;
				p = (NODE*)malloc(sizeof(NODE));
				p->start = q->start;
				p->len = q->len;
				p->link = NULL;

				last1->link = p;
				last1 = p;
				printf("File %s deleted successfully.\n",tfn);
			}
			break;
		case 3:
			disp_dir();
			disp_free_list();
      			break;
		case 4:
			exit(0);	
		}
	}
}

